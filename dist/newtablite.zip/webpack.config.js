module.exports = {
  entry: './js/index.js',
  output: {
    filename: 'bundle.js'
  }
}